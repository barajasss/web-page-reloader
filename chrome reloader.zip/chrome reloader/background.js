chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if(req.msg === 'reload'){
        chrome.tabs.query({
            url: 'https://www.microworkers.com/jobs.php'
        }, tabs => {
            chrome.tabs.reload(tabs[0].id);
        });
    }
    else if(req.msg === 'active'){
        chrome.tabs.query({
            url: 'https://www.microworkers.com/jobs.php'
        }, tabs => {
            chrome.tabs.update(tabs[0].id, {
                active: true
            });
        });
    }
})

setInterval(() => {
    chrome.tabs.query({ active: true }, tabs => {
        activeTab = tabs[0];
        chrome.tabs.query({ 
            url: 'https://www.microworkers.com/jobs.php'
        }, tabs => {
            chrome.tabs.update(tabs[0].id, { active: true });
            setTimeout(() => {
                chrome.tabs.update(activeTab.id, { active: true });
            }, 100);
        });
    });
}, 2 * 60 * 1000);

//mins * sec * millisecond