const keywords = [
    "upvote",
    "Watch [+] Like",
    "Watch [+] Subscribe",
    "Search [+] Watch",
    "Subscribe [+] Like",
    "Search [+] View",
    "Comment [+] Watch",
    "Comment [+] Subscribe",
    "Youtube: Like",
    "Youtube: Watch",
    "Youtube: Subscribe",
    "Watch, Like",
    "TTV-App",
    "vote in contest",
    "data entry",
    "medium: clap",
    "name/email",
    "TTV-Youtube",
    "reply to email",
    "clap"
];

const jobnames = document.getElementsByClassName("jobname");
const jobnamesArray = Array.from(jobnames);
const regex = createRegex(keywords);
let found = false;
let matches = 0;

console.log("regex: ", regex);

for(jobname of jobnamesArray){
    let a = jobname.firstChild.nextSibling.firstChild.nextSibling;
    if(jobname.innerText.match(regex)){
        found = true;
        matches++;
        a.innerHTML = `<span style="background-color: yellow">${a.innerText}</span>`;
    }
}

if(!found){
    document.title = "Reloading in 8 sec...";
    setTimeout(() => {
        chrome.runtime.sendMessage({
            msg: "reload"
        });
    }, 8000);
}
else{
    document.title = matches + (matches > 1 ? " matches": " match") + " found";
    chrome.runtime.sendMessage({
        msg: "active"
    });
}




function createRegex(keywords){
    let regexString = "(";
    regexString += keywords.join("|");
    regexString += ")";
    return new RegExp(regexString, "i");
}

